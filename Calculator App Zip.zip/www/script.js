let newLine = true;
let value1 = null;
let currentOperator = null;

function digitBtnPressed(digit) {
    const inputBox = document.getElementById("inputBox");

    if (newLine || inputBox.value === "0") {
        if (digit === '.' && inputBox.value.includes('.')) return;
        inputBox.value = digit;
        newLine = false;
    } else {
        if (digit === '.' && inputBox.value.includes('.')) return;
        inputBox.value += digit;
    }
}

function btnACPressed() {
    document.getElementById("inputBox").value = "0";
    newLine = true;
    value1 = null;
    currentOperator = null;
}

function operatorBtnPressed(operator) {
    value1 = parseFloat(document.getElementById("inputBox").value);
    currentOperator = operator;
    newLine = true;
}

function equalsBtnPressed() {
    const value2 = parseFloat(document.getElementById("inputBox").value);
    let result = 0;

    if (value1 === null || currentOperator === null) return;

    switch (currentOperator) {
        case '+':
            result = value1 + value2;
            break;
        case '-':
            result = value1 - value2;
            break;
        case '*':
            result = value1 * value2;
            break;
        case '/':
            result = value2 === 0 ? "Error" : value1 / value2;
            break;
    }

    document.getElementById("inputBox").value = result;
    value1 = result === "Error" ? null : result;
    newLine = true;
}
